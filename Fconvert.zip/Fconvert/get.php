<?php

header('Content-Type: application/json; charset=utf-8');

// =====================================================
// CONFIGURATION
// =====================================================

// Change this to a long, random secret.
// The same key must be used by your Python script.
define('API_KEY', 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET');

// Includes directory relative to get.php.
define('INCLUDES_DIR', __DIR__ . '/includes');


// =====================================================
// JSON RESPONSE
// =====================================================

function respond($status, $data)
{
    http_response_code($status);

    echo json_encode($data, JSON_PRETTY_PRINT);

    exit;
}


// =====================================================
// AUTHENTICATION
// =====================================================

$providedKey = $_SERVER['HTTP_X_API_KEY'] ?? '';

if (!hash_equals(API_KEY, $providedKey)) {
    respond(403, [
        'success' => false,
        'message' => 'Unauthorized request'
    ]);
}


// =====================================================
// VALIDATE REQUEST
// =====================================================

$hasMain = isset($_GET['main']);
$hasSec = isset($_GET['sec']);

if ($hasMain === $hasSec) {
    respond(400, [
        'success' => false,
        'message' => 'Provide exactly one of main or sec'
    ]);
}

$identifier = $hasMain
    ? $_GET['main']
    : $_GET['sec'];

if (!is_string($identifier) ||
    !preg_match('/^[0-9]{1,20}$/D', $identifier)) {

    respond(400, [
        'success' => false,
        'message' => 'Invalid ad unit identifier'
    ]);
}


// =====================================================
// DETERMINE TARGET FILES
// =====================================================

if ($hasMain) {

    $files = glob(
        INCLUDES_DIR . '/converter-p*',
        GLOB_NOSORT
    );

    $action = 'main';

} else {

    $files = [
        INCLUDES_DIR . '/t.php'
    ];

    $action = 'sec';
}


if (!$files) {
    respond(404, [
        'success' => false,
        'message' => 'No matching files found'
    ]);
}


// =====================================================
// UPDATE ONE FILE
// =====================================================

function update_file($file, $identifier)
{
    if (!is_file($file) || is_link($file)) {
        return [
            'success' => false,
            'message' => 'Not a regular file'
        ];
    }

    if (!is_readable($file) || !is_writable($file)) {
        return [
            'success' => false,
            'message' => 'File is not readable or writable'
        ];
    }

    // Lock the file while modifying it.
    $handle = fopen($file, 'c+');

    if (!$handle) {
        return [
            'success' => false,
            'message' => 'Could not open file'
        ];
    }

    if (!flock($handle, LOCK_EX)) {
        fclose($handle);

        return [
            'success' => false,
            'message' => 'Could not lock file'
        ];
    }

    rewind($handle);

    $content = stream_get_contents($handle);

    if ($content === false) {

        flock($handle, LOCK_UN);
        fclose($handle);

        return [
            'success' => false,
            'message' => 'Could not read file'
        ];
    }

    // -----------------------------------------
    // FIND SURFE AD TAGS AND REPLACE DATA-SID
    // -----------------------------------------

    $replacementCount = 0;

    $updatedContent = preg_replace_callback(

        '~<ins\b[^>]*>~i',

        function ($matches) use (
            $identifier,
            &$replacementCount
        ) {

            $tag = $matches[0];

            // Check that this is a surfe-be tag.

            if (!preg_match(
                '~\bclass\s*=\s*(["\'])(.*?)\1~i',
                $tag,
                $classMatch
            )) {
                return $tag;
            }

            $classes = preg_split(
                '/\s+/',
                trim($classMatch[2])
            );

            if (!in_array('surfe-be', $classes, true)) {
                return $tag;
            }

            // Replace the existing data-sid.

            $newTag = preg_replace_callback(

                '~\bdata-sid\s*=\s*(["\'])(.*?)\1~i',

                function ($attribute) use ($identifier) {

                    return 'data-sid="' . $identifier . '"';

                },

                $tag,

                1,

                $count
            );

            if ($count > 0) {
                $replacementCount += $count;
            }

            return $newTag;

        },

        $content
    );


    if ($updatedContent === null) {

        flock($handle, LOCK_UN);
        fclose($handle);

        return [
            'success' => false,
            'message' => 'Regex processing failed'
        ];
    }


    // -----------------------------------------
    // NO MATCHING TAGS
    // -----------------------------------------

    if ($replacementCount === 0) {

        flock($handle, LOCK_UN);
        fclose($handle);

        return [
            'success' => false,
            'message' => 'No matching Surfe tags found',
            'replacements' => 0
        ];
    }


    // -----------------------------------------
    // WRITE UPDATED CONTENT
    // -----------------------------------------

    rewind($handle);

    $written = ftruncate($handle, 0);

    if ($written) {

        $length = strlen($updatedContent);
        $offset = 0;

        while ($offset < $length) {

            $bytes = fwrite(
                $handle,
                substr($updatedContent, $offset)
            );

            if ($bytes === false || $bytes === 0) {
                $written = false;
                break;
            }

            $offset += $bytes;
        }
    }

    fflush($handle);

    flock($handle, LOCK_UN);
    fclose($handle);


    if (!$written) {

        return [
            'success' => false,
            'message' => 'Failed to write updated file'
        ];
    }


    return [
        'success' => true,
        'replacements' => $replacementCount
    ];
}


// =====================================================
// PROCESS FILES
// =====================================================

$results = [];

$totalReplacements = 0;
$successfulFiles = 0;

foreach ($files as $file) {

    if (!is_file($file)) {
        continue;
    }

    $result = update_file(
        $file,
        $identifier
    );

    $filename = basename($file);

    $results[$filename] = $result;

    if ($result['success']) {

        $successfulFiles++;

        $totalReplacements += $result['replacements'];
    }
}


// =====================================================
// FINAL RESPONSE
// =====================================================

if ($successfulFiles === 0) {

    respond(404, [
        'success' => false,
        'action' => $action,
        'identifier' => $identifier,
        'message' => 'No files were successfully updated',
        'files' => $results
    ]);
}


respond(200, [

    'success' => true,

    'action' => $action,

    'identifier' => $identifier,

    'files_updated' => $successfulFiles,

    'total_replacements' => $totalReplacements,

    'files' => $results

]);

?>